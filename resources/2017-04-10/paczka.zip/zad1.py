# -*- coding: utf-8 -*-

# Na przekór krytykom filmowym, Batman i Superman stają do walki siejąc spustoszenie w Metropolis!
# Pole bitwy to miasto przedstawione jako graf w pliku w bvs.gml. Wierzchołkami grafu są dzielnice miasta, a krawędziami
# główne ulice je łączące. Dla ułatwienia nazwa (label) każdej dzielnicy jest taka sama jak jej id, czyli wyrażona numerem.
# Batman ma swoje centrum dowodzenia w dzielnicy oznaczonej jako BATMAN_ADDRESS, z kolei Superman zawsze zaczyna
# swój dzień w dzielnicy SUPERMAN_ADDRESS.
# Każdy z bohaterów rozpoczyna patrol ze swojej bazy i poszukuje złoczyńców w sąsiednich dzielnicach. Każdy robi to
# na swój sposób, opisany poniżej, w nagłówkach funkcji batman() oraz superman().
# Ogranicza ich jednak moc (BATMAN_POWER, SUPERMAN_POWER), którą tracą na dotarcie z dzielnicy X do Y. Koszty podróży
# między dzielnicami zapisane są jako atrybuty value w krawędziach grafu.
#
# Twoim zadaniem jest sprawdzenie, który z bohaterów jest w stanie uratować więcej dzielnic, zanim wyczerpie swoją moc.
# Rozstrzygnij ich spór już dziś - w nagrodę nie będziesz musiał(a) oglądać filmu :)
#
# Uzupełnij kod funkcji load_city(), superman() oraz batman(). Podaj ile dzielnic kontroluje Batman, a ile Superman.


BATMAN_POWER = 100
SUPERMAN_POWER = 100

BATMAN_ADDRESS = 1111
SUPERMAN_ADDRESS = 1075


def load_city():
    return None


# Batman skacze z dachu na dach i preferuje dokładną eksplorację najbliższego otoczenia. Najpierw odwiedza więc
# wszystkie dystrykty sąsiadujące z tym, w którym obecnie się znajduje, a potem powraca do pierwszego z sąsiadów
# i powtwarza operację dla jego sąsiadów.
def batman(city, start_id):
    return 0

# Superman lubi latać z dużą prędkością. Z tego powodu najłatwiej mu odlecieć od startu tak daleko, jak to możliwe
# (sprawdzając po drodze kolejne dzielnice), a potem cofnąć się do ostatniego skrzyżowania i powtórzyć dla niego
# całą operację.
def superman(city, start_id):
    return 0


def fight(city, batman_start, superman_start):
    batman_score = batman(city, batman_start)
    superman_score = superman(city, superman_start)

    if batman_score > superman_score:
        print("Batman: I won! You know why ? Because I'M BATMAN!")
    else:
        print("Superman: srx dude, I won. #itsnotyourfaultben")


if __name__ == '__main__':
    city = load_city()
    fight(city, BATMAN_ADDRESS, SUPERMAN_ADDRESS)
