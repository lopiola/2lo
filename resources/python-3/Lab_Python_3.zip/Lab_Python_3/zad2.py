# -*- coding: utf-8 -*-
# Wczytaj tekst dowolnej powieści i stwórz tzw. słownik frekwencyjny: policz liczbę wystąpień każdego słowa w powieści,
# a następnie wypisz 50 najczęściej używanych słów, wraz z liczbą wystąpień.
#
# Wskazówka : problem wyciągania słów z tekstu można w prosty sposób rozwiązać, używając tzw. wyrażeń regularnych.
# Poczytaj o wyrażeniach regularnych w pythonie tutaj: https://docs.python.org/2/library/re.html



def get_sorted_keys(d):
   return sorted(d, key=d.get, reverse=True)


if __name__ == '__main__':