# -*- coding: utf-8 -*-
# Skracanie ułamków tak przypadło Ci do gustu, że postanowiłeś/aś napisać program, który będzie przetwarzał setki,
# tysiące, a nawet miliony ułamków! Oczywiście ułamki nie będą podawane ręcznie -
# od teraz znajdują się pliku ulamki.txt
#
# a) Zmodyfikuj odpowiednie funkcje programu tak, by ułamki nie były podawane przez użytkownika tylko wczytywane z pliku.
#    Każda linia pliku reprezentuje jeden ułamek i jest zapisana w formacie "licznik mianownik".
#    Skrócone ułamki powinny zostać zapisane w pliku tekstowym wyniki.txt
# b) Dodaj obsługę błędów w programie. Zadbaj zarówno o sytuacje wyjątkowe przy operacjach na plikach, jak i o błędy danych

def wyszukiwanie_dzielnika(licznik, mianownik):
    while licznik != mianownik:
        if licznik > mianownik:
            licznik -= mianownik
        else:
            mianownik -= licznik
    return mianownik

def wczytaj_ulamki():
    ulamki = []
    for i in range(1):
        licznik = int(input())
        mianownik = int(input())
        ulamki.append((licznik, mianownik))
    return ulamki

def skracanie(licznik, mianownik):
    dzielnik = wyszukiwanie_dzielnika(licznik, mianownik)
    licznik //= dzielnik
    mianownik //= dzielnik
    if mianownik == 1:
        return licznik
    else:
        return licznik, mianownik

def wypisz_wyniki(wyniki):
    for w in wyniki:
        print(w)

if __name__ == '__main__':
    wyniki = []
    for licznik, mianownik in wczytaj_ulamki():
        wynik = skracanie(licznik, mianownik)
        wyniki.append(wynik)

    wypisz_wyniki(wyniki)