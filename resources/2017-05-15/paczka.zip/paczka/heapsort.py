#!/usr/bin/env python
# -*- coding: utf-8 -*-

# TODO Zad 1) Zaimplementuj podstawowe funkcje pozwalajace na wczytywanie liczb z plikow i ich wypisywanie
# TODO Zad 2) Zaimplementuj sortowanie babelkowe
# TODO Zad 3) Zaimplementuj sortowanie przez kopcowanie
# TODO Zad 4) Porownaj czasy sortowania obiema metodami dla roznych wielkosci danych
#   (skorzystaj z roznych plikow zawierajacych liczby) - jakie sa wnioski? Z czego wynikaja roznice?
# TODO Zad 5) Rozszerz glowna funkcje o sortowanie listy natywna funkcja pythona, razem z pomiarem czasu i wypisaniem
#   wyniku. Pamietaj, aby sortowac nieposortowana liste! Jak spisuje sie natywny algorytm pythona wzgledem naszych?
#   Znajdz online informacje jaki algorytm jest tam uzywany (chodzi o nazwe, zasady dzialania nie trzeba znac).
# TODO Zad 6) Rozszerz glowna funkcje o sortowanie juz posortowanej listy wszystkimi 3 metodami, razem z pomiarem czasu.
#   Przeanalizuj otrzymane wyniki. Jak je wytlumaczysz?


import sys
import time


# TODO Zad 1) Ta funkcja wczytuje liczby z pliku okreslonego przez sciezke
# i zwrocic liste zawierajaca te liczby. Liczby w plikach oddzielane sa nowa linia.
def read_numbers(file_name):
    return []


# TODO Zad 1) Ta funkcja wypisuje liczby na ekran zawarte w podanej liscie
# zgodnie z nastepujacymi wytycznymi
#   - liczby oddzielone spacjami
#   - jesli jest nie wiecej niz 20 liczb, wypisujemy wszystkie
#   - jesli jest powyzej 20 liczb, wypisujemy pierwsze i ostatnie 10, oddzielajac je trzykropkiem
def print_numbers(numbers):
    print('liczby liczby')


# TODO Zad 2) Ta funkcja zamienia miejscami liczbe na pozycji 'a' z liczba na pozycji 'b', operujac na podanej liscie liczb.
# Przyda sie zarowno w sortowaniu babelkowym, jak i przez kopcowanie.
# Nie zwraca niczego.
def swap(list, a, b):
    return


# TODO Zad 2) Ta funkcja wykonuje sortowanie metoda babelkowa, operujac na podanej liscie liczb.
# Nie zwraca niczego.
def bubble_sort(numbers):
    return


# TODO Zad 3) Ta funkcja wykonuje kopcowanie liczby pod danym 'index'em, operujac na kopcu zawartym w liscie 'heap'. 
# Polega to na 'przepchnieciu' liczby W GORE, az warunek kopca bedzie spelniony. Nie musimy tutaj podawac rozmiaru kopca,
# poniewaz zawsze poruszamy sie w strone poczatku listy (warunkiem konca jest osiagniecie indeksu 0).
def heapify_up(heap, index):
    return


# TODO Zad 3) Ta funkcja wykonuje kopcowanie liczby pod danym 'index'em, operujac na kopcu zawartym w liscie 'heap' o
# rozmiarze 'heap_size'. Polega to na 'przepchnieciu' liczby W DOL, az warunek kopca bedzie spelniony. Wielkosc
# kopca jest podawana, aby bylo wiadomo kiedy osiagamy koniec kopca i nalezy zatrzymac procedure (kopiec nie musi
# zajmowac calej listy).
def heapify_down(heap, index, heap_size):
    return


# TODO Zad 3) Ta funkcja wykonuje sortowanie metoda kopcowania, operujac na podanej liscie liczb.
# Kroki algorytmu:
#   1. Kopcowanie liczb w miejscu, tj uzywajac tej samej listy w ktorej sie znajduja. Polega na stopniowym przeksztalcaniu
#       listy w kopiec, zaczynajac od poczatku i dla kazdego elementu wykonujac 'przepychanie' go W GORE.
#   2. Kolejne 'sciaganie' liczby z korzenia kopca poprzez zamiane z ostatnia liczba i zmniejszenie kopca o jeden, a
#       nastepnie przepychanie nowego korzenia W DOL w celu zachowania warunku kopca. Powtarzane az wielkosc kopca zmniejszy
#       sie do zera.
# Nie zwraca niczego.
def heapsort(numbers):
    return


if __name__ == '__main__':
    # TODO Zad 1) Nazwa pliku ma byc podawana przez pierwszy argument, w razie niepodania wyswietlic odpowiedni komunikat
    number_list = read_numbers('liczby-malo.txt')
    # Kopiujemy liste liczb, zeby miec dwie takie same listy do posortowania
    number_list_2 = number_list[:]

    print('Przed sortowaniem [{} liczb]:'.format(len(number_list)))
    print_numbers(number_list)
    print('')

    t = time.time()
    bubble_sort(number_list)
    time_elapsed = time.time() - t
    print('Sortowanie przez babelkowe [{0:.5f} sekund]:'.format(time_elapsed))
    print_numbers(number_list)
    print('')

    t = time.time()
    heapsort(number_list_2)
    time_elapsed = time.time() - t
    print('Sortowanie przez kopcowanie [{0:.5f} sekund]:'.format(time_elapsed))
    print_numbers(number_list_2)
    print('')

