from tkinter import *


class Gui(Frame):
    def __init__(self, parent, message_dispatcher):
        Frame.__init__(self, parent)
        parent.title("Server")
        self.message_dispatcher = message_dispatcher
        self.parent = parent
        frame = Frame(parent)
        self.text_output = Text(frame, width = 35, height = 20)
        self.text_output.config(state=DISABLED)
        scroll = Scrollbar(frame, orient=VERTICAL, command=self.text_output.yview)
        self.text_output['yscroll'] = scroll.set
        scroll.pack(side="right", fill="y")
        self.text_output.pack()
        frame.pack()
        self.text_input = Text(self.parent, width = 37, height = 5)
        self.text_input.pack()
        self.send_button = Button(self.parent, text="Send", command=lambda: self.send_message())
        self.send_button.pack()
        self.parent.bind('<Return>', self.onEnter)
        self.parent.after(1, self.update)
        self.parent.mainloop()

    def onEnter(self, event):
        self.send_message()

    def put_message(self, message):
        self.text_output.config(state=NORMAL)
        self.text_output.insert(END, message)
        self.text_output.config(state=DISABLED)
        self.text_output.see(END)

    def send_message(self):
        message = self.text_input.get("1.0","end-1c").strip()
        self.text_input.delete('1.0', END)
        self.put_message('ADMIN: '+ message + '\n')
        self.message_dispatcher.send(message)

    def update(self):
        message = self.message_dispatcher.listen()
        if (message != ""):
            self.put_message(message + '\n')
        self.parent.after(1, self.update)