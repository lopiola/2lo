import socket
import pickle

SERVER_NAME = 'localhost'
PORT = 10000


class MessageDispatcher:
    def __init__(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setblocking(0)
        self.server_address = (SERVER_NAME, PORT)
        self.sock.bind(self.server_address)
        self.sock.listen()
        self.connections = []

    def listen(self):
        self.appendConnection()
        data = self.listenForMessage()
        if (data!=""):
            self.propagateMessage(data)
            print(data)
            return data["NICK"] + ": " + data["MESSAGE"]
        return ""


    def appendConnection(self):
        try:
            connection, client_address = self.sock.accept()
            connection.setblocking(0)
            self.connections.append(connection)
            print("new connection")
        except:
            pass

    def listenForMessage(self):
        for connection in self.connections:
            try:
                dataObj = connection.recv(1024)
                data = pickle.loads(dataObj)
                #print(data)
                if data["COMMAND"] == "MESSAGE" and data["MESSAGE"] != "" and data["NICK"] != "":
                    return data
                else:
                    return ""
            except:
                pass
        return ""

    def propagateMessage(self, message):
        for connection in self.connections:
            try:
                connection.sendall(pickle.dumps(message))
            except:
                connection.close()
                self.connections.remove(connection)

    def send(self, message):
        dataToSend = {}
        dataToSend["COMMAND"]="MESSAGE"
        dataToSend["MESSAGE"]=message
        dataToSend["NICK"]= "ADMIN"
        self.propagateMessage(dataToSend)

