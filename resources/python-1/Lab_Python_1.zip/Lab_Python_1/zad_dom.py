# -*- coding: utf-8 -*-

# Pewien uczeń II LO do perfekcji opanował sztuczkę z ważeniem 9 monet i odnajdywaniem wśród nich fałszywej,
# lżejszej niż reszta. Jednak wkrótce okazało się, że jego sztuczka jest dobrze znana i łatwo znaleźć ją w Internecie.
# Potrzebował więc czegoś znacznie większego. Po wielu latach prób i błędów udało mu się opracować algortym,
# który umożliwia znalezienie fałszywej, lżejszej monety wśród 100 monet... porównując wagi monet jedynie 7 razy!
#
# Wskazówka 1 : ten uczeń to Ty.
# Wskazówka 2 : zbadanie tematu "wyszukiwanie połówkowe" może być przydatne
# Wskazówka 3 : liczby nieparzyste są nieprzyjemne, pamiętaj o nich! Pamiętaj również, że wynik dzielenia w Pythonie
#               jest liczbą rzeczywistą! Do dzielenia całkowitego użyj operatora // .
#               np. 25/2 = 12.5, 25//2 = 12
# Wskazówka 4 : Znamy wagę prawidłowej monety, wynosi ona CORRECT_COIN_WEIGHT.
# Zagadka: Jeśli zmienilibyśmy wartość COIN_NO na dowolną inną to program nadal by działał ?
# W ilu krokach znajdowałby rozwiązanie dla N monet ?

# UWAGA - czesc zmiennych i funkcji w tym module zaczyna się od "_" - to znaczy, ze nie wolno ich uzywac! ;]

import random

# Liczba wszystkich monet
COIN_NO = 100

# Waga prawidłowej monety
CORRECT_COIN_WEIGHT = 1.0

random.seed()



_LOW_COIN_WEIGHT = CORRECT_COIN_WEIGHT - random.uniform(0.1, 0.2)


_ALL_COINS = [i for i in range(COIN_NO)]

_FALSE_COIN = random.choice(_ALL_COINS)


# Funkcja pozwalajaca na wazenie fragmentu listy monet. Jej argumentami są dwie liczby, wyznaczające zakres ważonych monet [i,j).
# Np. i=2, j=5 : funkcja zwróci wagę monet od monety nr 2 do monety nr 4 włącznie.
def weigh(i, j):
    weighs = [CORRECT_COIN_WEIGHT
              if coin != _FALSE_COIN
              else _LOW_COIN_WEIGHT
              for coin in _ALL_COINS[i:j]]
    return sum(weighs)


# Funkcja pozwalajaca na zgloszenie nieprawidlowej monety. Jako argument podawany jest numer monety z listy monet.
def report_false(coin):
    if coin == _FALSE_COIN:
        print("Znaleziono falszywa monete!")
    else:
        print("To nie jest falszywa moneta.")


if __name__ == '__main__':
    false_coin = 0
    report_false(false_coin)
