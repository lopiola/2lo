# -*- coding: utf-8 -*-

# Napisz program, który wczyta 2 liczby : A i B, a następnie wypisze największy wspólny dzielnik (NWD) dla tych liczb.
# Skorzystaj z algorytmu Euklidesa: "Dopóki A i B nie są sobie równe, odejmuj mniejszą z nich od większej.
# Gdy A jest równe B, jest równocześnie szukanym NWD".
#
# a) Przygotuj schemat blokowy dla opisanego problemu.
# b) Napisz program na podstawie schematu.

if __name__ == '__main__':
    # Tutaj napisz swój program
