# -*- coding: utf-8 -*-

# W roju Zergów nie istnieje problem niżu demograficznego. W każdym kolejnym pokoleniu rodzi się coraz więcej
# Zerglingów. W momencie założenia nowej Wylęgarni pojawia się 1 Zergling. W drugim pokoleniu znów rodzi się 1 Zergling.
# Jednak w każdym kolejnym rodzi się tyle Zerglingów, ile w sumie urodziło się w dwóch poprzednich pokoleniach:
# w trzecim 2, w czwartym 3, w piątym 5, itd.
# Chcesz opracować precyzyjny plan zagłady świata, dlatego będzie Ci potrzebny program, który dla zadanej liczby
# N podpowie, ile Zerglingów wykluje się w N-tym pokoleniu.
# Program powinien wczytać liczbę N z wejścia i wypisać liczbę Zerglingów urodzonych w N-tym pokoleniu.
#
# a) Przygotuj schemat blokowy dla opisanego problemu.
# b) Napisz program na podstawie schematu.



if __name__ == '__main__':
    # For The Swarm!