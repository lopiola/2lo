import socket

SERVER_NAME = 'localhost'
PORT = 10000


class MessageDispatcher:
    def __init__(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_address = (SERVER_NAME, PORT)
        self.sock.bind(self.server_address)
        self.sock.listen(1)
        self.connection, self.client_address = self.sock.accept()
        self.connection.setblocking(0)

    def listen(self):
        try:
            data = self.connection.recv(1024)
            return data.decode()
        except:
            return ""

    def send(self, message):
        self.connection.sendall(message.encode())

