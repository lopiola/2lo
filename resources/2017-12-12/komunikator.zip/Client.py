import socket

SERVER_NAME = 'localhost'
PORT = 10000


class MessageDispatcher:
    def __init__(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_address = (SERVER_NAME, PORT)
        self.sock.connect(server_address)
        self.sock.setblocking(0)

    def listen(self):
        try:
            data = self.sock.recv(1024)
            return data.decode()
        except:
            return ""

    def send(self, message):
        self.sock.sendall(message.encode())