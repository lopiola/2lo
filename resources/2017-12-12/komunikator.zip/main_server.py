from Server import MessageDispatcher
from tkinter import *
from Gui import Gui


message_dispatcher = MessageDispatcher()
root = Tk()
gui = Gui(root, message_dispatcher)