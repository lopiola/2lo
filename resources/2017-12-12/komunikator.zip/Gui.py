from tkinter import *


class Gui(Frame):
    def __init__(self, parent, message_dispatcher):
        Frame.__init__(self, parent)
        self.message_dispatcher = message_dispatcher
        self.parent = parent
        self.text_output = Text(self.parent, width = 35, height = 5)
        self.text_output.config(state=DISABLED)
        self.text_output.pack()
        self.text_input = Text(self.parent, width = 35, height = 5)
        self.text_input.pack()
        self.send_button = Button(self.parent, text="Send", command=lambda: self.send_message())
        self.send_button.pack()
        self.parent.after(1, self.update)
        self.parent.mainloop()

    def put_message(self, message):
        self.text_output.config(state=NORMAL)
        self.text_output.insert(END, message)
        self.text_output.config(state=DISABLED)

    def send_message(self):
        message = self.text_input.get("1.0","end-1c")
        self.text_input.delete('1.0', END)
        self.put_message('Ja: '+ message + '\n')
        self.message_dispatcher.send(message)

    def update(self):
        message = self.message_dispatcher.listen()
        if (message != ""):
            self.put_message('Rozmówca: '+ message + '\n')
        self.parent.after(1, self.update)