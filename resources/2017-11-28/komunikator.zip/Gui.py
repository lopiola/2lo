from tkinter import *


class Gui(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent)
        self.parent = parent
        self.text_output = Text(self.parent, width = 55, height = 25)
        self.text_output.config(state=DISABLED)
        self.text_output.pack()
        self.text_input = Text(self.parent, width = 55, height = 5)
        self.text_input.pack()
        self.send_button = Button(self.parent, text="Send", command=lambda: self.send_message())
        self.send_button.pack()

    def send_message(self):
        message = self.text_input.get("1.0",END)
        self.text_input.delete('1.0', END)
        self.text_output.config(state=NORMAL)
        self.text_output.insert(END, 'Ja: '+ message)
        self.text_output.config(state=DISABLED)

    def update(self):
        pass


    def start(self):
        self.parent.after(500, self.update)
        self.parent.mainloop()