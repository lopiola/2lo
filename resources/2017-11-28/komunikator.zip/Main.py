from Gui import *


root = Tk()
gui = Gui(root)
gui.start()