#!/usr/bin/env python

# Zaimplementuj klase 'Postac' tak aby posiadala:
#   Atrybuty:
#       imie
#       punkty_zycia
#   Metody (funkcje):
#       status - wypisuje na ekran status postaci, w zaleznosci od tego czy punktu zycia <= 0:
#           <imie> nie zyje! LUB
#           <imie> ma sie dobrze posiadajac jeszcze <punkty_zycia> punktow zycia.
#
#       oberwij(obrazenia) - zadaje obrazenia postaci w liczbie podanej w argumencie
#
#   Nie zapomnij o konstruktorze! ( funkcja __init__ ) Powinien przyjmowac imie postaci i jej startowa
#       liczbe punktow zycia.

class Postac():
    # TODO

# Glowna funkcja programu
if __name__ == '__main__':
    postac = Postac('Rycerz Stanislaw', 100)
    postac.status()
    postac.oberwij(73)
    postac.status()
    postac.oberwij(41)
    postac.status()
