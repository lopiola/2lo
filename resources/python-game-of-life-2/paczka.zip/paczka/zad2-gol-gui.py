#!/usr/bin/env python

from Tkinter import *
import tkFileDialog
import sys
import time
import random

# Implementacja gry w zycie w okienku. Dla ciekawskich: https://pl.wikipedia.org/wiki/Gra_w_%C5%BCycie
# Wykorzystano kod stworzony wspolnie na zajeciach 3 stycznia 2017, uzyj go w odpowiednich miejscach.
#
# Zadania do wykonania:
#   1) Przeanalizuj ponizszy kod.
#   2) Przyjrzyj sie funkcji create_board_graphics. Na razie zawiera ona wydmuszke, zaimplementuj poprawnie te funkcje.
#   3) Przyjrzyj sie funkcji refresh_board. Na razie zawiera ona wydmuszke, zaimplementuj poprawnie te funkcje.
#       Zobacz gdzie tworzony jest canvas, bedzie potrzebne tam ustawienie odpowiedniej wielkosci, aby cala plansza
#       miescila sie w okienku.
#   4) Zaimplementuj dzialanie guzika 'Start' (funkcja start_button_action).
#       Z poczatku symulacja powinna byc zatrzymana, a ten guzik powinien ja uruchamiac.
#   5) Stworz guzik 'Stop' w gornym menu i zaimplementuj jego dzialanie.
#       Powinien on zatrzymac dzialajaca symulacje (przerwac petle game_loop).
#   6) Stworz guzik 'Wyczysc' w gornym menu i zaimplementuj jego dzialanie.
#       Gdy gra jest zatrzymana, powinien wyczyscic plansze.
#   7) Stworz guzik 'Losuj' w gornym menu i zaimplementuj jego dzialanie.
#       Gdy gra jest zatrzymana, powienien wylosowac nowa plansze.
#   8) Zaimplementuj dzialanie guzika 'Wczytaj z pliku' (funkcja load_button_action).
#       Gdy gra jest zatrzymana, powienien wczytac plansze z zadanego pliku.
#   9) Zaimplementuj funkcje 'click_on_canvas_action'.
#       Gdy gra jest zatrzymana, klikniecie na planszy powinno przelaczac kliknieta komorke miedzy zywa a martwa.
#   10) Spraw, aby tylko guzik "Stop" byl aktywny gdy symulacja jest aktywna, a cala reszta gdy jest wstrzymana. Uzyj
#       w tym celu funkcji configure i atrybutu guzika 'state', ktory moze miec wartosc DISABLED lub NORMAL.
#   11) Stworz guzik 'Zapisz do pliku' w gornym menu i zaimplementuj jego dzialanie.
#       Gdy gra jest zatrzymana, powienien zapisac plansze do wskazanego pliku.
#       Uzyj funkcji tkFileDialog.asksaveasfilename.
#


# Dlugosc boku planszy
#   18 to minimum aby pentadecathlon i pulsar dzialaly poprawnie
#   50 to minimum aby glider-gun dzialal poprawnie
BOARD_SIZE = 40
# Ile komorek powinno zostac wylosowanych przy losowaniu planszy
RANDOMIZATION_SIZE = int(BOARD_SIZE * BOARD_SIZE * 0.4)

# Co ile czasu nastepuje kolejna runda (w milisekundach)
ROUND_INTERVAL = 200

# Znak oznaczajacy zywa komorke w pliku wejsciowym
ALIVE_CELL_CHAR_FROM_FILE = '*'

# Znak oznaczajacy martwa komorke w pliku wejsciowym
DEAD_CELL_CHAR_FROM_FILE = '-'

# Przy jakiej liczbie sasiadow zywa komorka przezyje
CELL_SURVIVES = [2, 3]
# Przy jakiej liczbie sasiadow martwa komorka ozyje
CELL_COMES_ALIVE = [3]

# PARAMETRY DOTYCZACE GUI
# Jaki bok ma miec kazda komorka (w pixelach)
GUI_CELL_SIZE = 10
# Jaki kolor ma miec tlo oraz martwe komorki
GUI_BACKGROUND_COLOR = 'white'
# Jaki kolor ma miec obwodka komorki
GUI_CELL_OUTLINE_COLOR = 'gray'
# Jaki kolor ma miec zywa komorka
GUI_ALIVE_CELL_COLOR = 'red'


class GameOfLife(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent)
        self.parent = parent
        self.parent.title('Game of Life GUI')
        self.grid()

        # Przechowuje stan planszy
        self.board = self.create_board()
        # Numer rundy
        self.round_number = 0

        # Inicjalizacja guzikow w panelu gornym
        self.top_panel = Frame(self)
        self.top_panel.grid(row=0, column=0)

        self.start_button = Button(self.top_panel, text='Start', command=self.start_button_action)
        self.start_button.grid(row=0, column=0)

        self.load_button = Button(self.top_panel, text='Wczytaj z pliku', command=self.load_button_action)
        self.load_button.grid(row=0, column=1)

        self.round_label = Label(self, text='Round: {}'.format(self.round_number))
        self.round_label.grid(row=1, column=0)

        # Inicjalizacja obiektu canvas w panelu dolnym i komorek rysowanych w okienku
        self.bottom_panel = Frame(self)
        self.bottom_panel.grid(row=2, column=0)
        self.canvas = Canvas(self.bottom_panel,
                             width=300,  # TODO uzaleznij rozmiar canvas od ilosc i wielkosci komorek
                             height=300,
                             highlightthickness=0, bd=0,
                             background=GUI_BACKGROUND_COLOR)
        # Przypisanie akcji kliniecia na canvas
        self.canvas.bind("<Button-1>", self.click_on_canvas_action)
        # Stworzenie grafiki - reprezentacji komorek
        self.board_graphics = self.create_board_graphics(self.canvas)
        # Przeliczenie i wyswietlenie zawartosci canvas
        self.canvas.pack()
        # Rozpoczecie symulacji
        self.game_loop()

    # Kod uruchamiany po kliknieciu w guzik Start
    def start_button_action(self):
        # TODO do zaimplementowania
        print('Kliknieto start!')

    # Kod uruchamiany po kliknieciu w guzik Wczytaj z pliku
    def load_button_action(self):
        # TODO do zaimplementowania
        filename = tkFileDialog.askopenfilename(defaultextension='.txt',
                                                filetypes=(('txt files', '*.txt'), ('All files', '*.*')))
        print('Wybrano plik {}'.format(filename))

    # Kod uruchamiany po kliknieciu na plansze
    def click_on_canvas_action(self, event):
        # TODO do zaimplementowania
        print "Kliknieto na wspolrzedne ({}, {})".format(event.x, event.y)

    # Tworzy graficzna reprezentacje komorek i ustawia je w okienku na obiekcie typu Canvas.
    # Zwraca tablice przechowujaca obiekty komorek (analogiczna do board).
    def create_board_graphics(self, canvas):
        # TODO ponizsza implementacja jest tylko wydmuszka i ma pokazac jak dodac kolorowe okregi (oval) do obiektu
        # typu canvas. Zastap to implementacja ktora stworzy kwadrat o boku BOARD_SIZE zlozony z malych okregow i
        # zwroci liste list przechowujaca te okregi. Uzyj stalej GUI_CELL_SIZE aby okreslic rozmiar okregu.
        board_graphics = []
        cell = canvas.create_oval(10, 10, 90, 90, outline='black', fill='green')
        board_graphics.append(cell)
        cell = canvas.create_oval(10, 110, 90, 190, outline='black', fill='blue')
        board_graphics.append(cell)
        cell = canvas.create_oval(110, 10, 190, 90, outline='black', fill='red')
        board_graphics.append(cell)
        cell = canvas.create_oval(110, 110, 190, 190, outline='black', fill='yellow')
        board_graphics.append(cell)
        return board_graphics

    # Wyswietla aktualny stan gry na podstawie atrybutu 'board'.
    def refresh_board(self):
        # TODO ponizsza implementacja jest tylko wydmuszka i ma pokazac jak zmieniac kolory okregow obiektu typu canvas.
        # Zastap to implementacja ktora na podstawie stanow komorek z atrybutu 'board' pokoloruje odpowiednio komorki
        # zywe oraz martwe. Uzyj stalych GUI_BACKGROUND_COLOR, GUI_CELL_OUTLINE_COLOR, GUI_ALIVE_CELL_COLOR.
        # TODO zaktualizuj Label wyswietlajacy numer rundy (funkcja configure, w argumencie podajemy wartosci atrybutow)
        colors = ['green', 'blue', 'red', 'yellow']
        for i in range(len(self.board_graphics)):
            color = random.choice(colors)
            self.canvas.itemconfig(self.board_graphics[i], fill=color)

    # Petla Gry w Zycie, ktora aktualizuje plansze i ja odswieza co jakis czas
    def game_loop(self):
        self.refresh_board()
        self.board = self.live()
        self.round_number += 1
        # Zaplanuj kolejne wykonanie tej funkcji po czasie ROUND_INTERVAL (w milisekundach).
        # Dzieki temu uzyskujemy efekt animacji.
        self.after(ROUND_INTERVAL, self.game_loop)

    # Tworzy PUSTA plansze (bez zywych komorek)
    # Zwraca plansze
    def create_board(self):
        x = []
        for j in range(BOARD_SIZE):
            x.append([])
            for i in range(BOARD_SIZE):
                x[j].append(False)
        # plansza powinna byc kwadratem o boku BOARD_SIZE
        # martwa komorka oznaczana jest False
        return x

    # Losuje stan poczatkowy planszy
    # Operuje na atrybucie klasy - 'board'
    def randomize_board(self):
        # nalezy wylosowac zywe komorki i zanaczyc je w 'board'
        # losowanie jednej komorki nalezy powtorzyc RANDOMIZATION_SIZE razy
        for i in range(RANDOMIZATION_SIZE):
            x = random.randint(0, BOARD_SIZE - 1)
            y = random.randint(0, BOARD_SIZE - 1)
            self.board[x][y] = True

    # Wczytuje stan poczatkowy z pliku do planszy przechowywanej w atrybucie klasy - 'board'
    # 1) jesli plansza w pliku jest mniejsza od board, wczytuje od lewego gornego naroznika
    # 2) jesli plansza w pliku jest wieksza od board, wczytuje tylko to co sie miesci
    # Wartosc zwracana nie jest istotna, plansza board powinna byc zmodyfikowana przez te funkcje
    def import_board_from_file(self, file_path):
        # nalezy uzyc ALIVE_CELL_CHAR_FROM_FILE i/lub DEAD_CELL_CHAR_FROM_FILE
        file = open(file_path)
        x = 0
        y = 0
        for i in file:
            if y >= BOARD_SIZE:
                break
            for j in i:
                if x >= BOARD_SIZE:
                    break
                if j == ALIVE_CELL_CHAR_FROM_FILE:
                    self.board[y][x] = True
                x += 1
            y += 1
            x = 0

    # Liczy sasiadow komorki o wspolrzednych (x, y) na planszy przechowywanej w atrybucie klasy - board
    # Zwraca wyliczona liczbe sasiadow
    def count_neighbours(self, x, y):
        # uwaga na warunki brzegowe!
        z = 0
        for i in range(x - 1, x + 2):
            for j in range(y - 1, y + 2):
                if i == x and j == y:
                    continue
                if i < 0 or j < 0 or i >= BOARD_SIZE or j >= BOARD_SIZE:
                    continue
                if self.board[i][j]:
                    z += 1
        return z

    # Wylicza jedna runde Gry w Zycie
    # Zwraca NOWA plansze board na podstawie starej, podanej przez argument
    def live(self):
        plansza = self.create_board()
        for i in range(BOARD_SIZE):
            for j in range(BOARD_SIZE):
                x = self.count_neighbours(i, j)
                if x in CELL_COMES_ALIVE and not self.board[i][j]:
                    plansza[i][j] = True
                if x in CELL_SURVIVES and self.board[i][j]:
                    plansza[i][j] = True
        # czy mozemy aktualizowac te sama plansze w ktorej liczymy sasiadow?
        # uzyc CELL_SURVIVES dla zywych komorek zeby stwierdzic czy przezyly
        # uzyc CELL_COMES_ALIVE dla martwych komorek zeby stwierdzic czy ozyly
        return plansza


# Glowna funkcja programu
if __name__ == '__main__':
    # Tworzymy obiekt biblioteki tKinter
    root = Tk()
    # Tworzymy obiekt GameOfLife
    GameOfLife(root)
    # Uruchamiamy procedure zarzadzajaca oknem
    root.mainloop()
