# -*- coding: utf-8 -*-
#
# Czas na ostateczny pojedynek! Wyznacz najlepszą trasę (taką, w której zużyje się najmniej mocy), którą musi przebyć
# Batman żeby dotrzeć ze swojego punktu startowego do bazy Supermana.
#
# Program powinien wypisać ilość mocy potrzebną na przebycie trasy. Mile widziana również sama ścieżka (kolejne dzielnice).
#
# Wskazówka : aby uzyskać wartość "nieskończoności" w pythonie, należy użyć wyrażenia: float('inf')


BATMAN_ADDRESS = 1111
SUPERMAN_ADDRESS = 1075

if __name__ == '__main__':




