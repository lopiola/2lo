# -*- coding: utf-8 -*-
# W końcu udało Ci się wybrać swój wymarzony samochód. Teraz czas na pierwszą jazdę!
#
# W zadaniu wykorzystaj klasę Car z zad1 . Do każdego z poleceń napisz krótki test w sekcji main.
#
# a) Dodaj do klasy Car metodę ride_the_lightning(time), która dla zadanego czasu time (w godzinach) obliczy
#    i zwróci dystans, który przejedzie samochód. Zakładamy, że najfajniej jeździ się prosto i z jednostajną,
#    maksymalną prędkością.
#
# b) Stwórz dodatkowy typ Person, który będzie posiadał 2 atrybuty: name i surname. Następnie dodaj do klasy Car
#    2 nowe metody: load(Person) i unload(Person) . Chcemy by do naszego samochodu dało się wsiadać i wysiadać.
#    Ale uwaga: każdy samochód ma określoną liczbę miejsc. Metody powinny zapisywać informacje o osobach, które są już
#    w samochodzie i pilnować by nie przekroczyć dostępnej liczby miejsc (rzucać wyjątkiem w takiej sytuacji).
#    Zastanów się, jakiej struktury danych użyć do przechowywania w klasie Car informacji o obiektach typu Person.
#    Uzasadnij swój wybór.
#
# c) Dodaj do klasy Car metodę __str__(), dzięki której będzie możliwe wypisywanie informacji o samochodzie
#    w pojedynczym wywołaniu print(car). Metoda powinna zwrócić tekst z informacjami o atrybutach i osobach,
#    znajdujących się aktualnie w samochodzie.