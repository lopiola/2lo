# -*- coding: utf-8 -*-
# Sprawa jest prosta: po 256. podejściu w końcu udało Ci się zdać egzamin na prawko, ale nie masz jak się tym nacieszyć,
# bo... nie posiadasz samochodu. Pozostaje więc przeglądnąć katalog pojazdów i wybrać najlepszy. Czyli czerwony.
#
# W pliku cars.csv znajduje się katalog samochodów. Każdy wiersz to parametry jednego modelu samochodu,
# oddzielone przecinkiem:

# marka,kolor,liczba miejsc,prędkość max (km/h)
#
# Zadanie polega na stworzeniu klasy (typu) Car i wczytaniu z pliku całego katalogu samochodów. Jako rezultat powinniśmy
# otrzymać listę obiektów typu Car.
# Następnie z otrzymanej listy należy wybrać jedynie czerwone samochody i wypisać ich parametry.
