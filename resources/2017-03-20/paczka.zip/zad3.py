# -*- coding: utf-8 -*-
# Stwórz klasę bazową Animal posiadającą pole "name" oraz abstrakcyjną metodę "talk" rzucającą odpowiedni wyjątek.
# Następnie stwórz klasę Cat i zaimplementuj metode "talk" w taki sposób, aby zwracała stringa: "Meow!".
# Stwórz klasę Dog i podobnie jak wcześniej zaimplementuj metodę "talk" w taki sposób, aby zwracała stringa: "Woof! Woof!"
# Stwórz pustą listę, a następnie dodaj do niej kilka instancji klas Cat i Dog.
# Przeiteruj po liście wywołująć dla każdego obiektu metodę "talk".


#your code


for animal in animals:
    print animal.name + ': ' + animal.talk()