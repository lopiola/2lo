# -*- coding: utf-8 -*-

# Pewna niewiasta zagubiła się w lesie, przypominającym labirynt. Dzielny lord Ramsay wyruszył jej na ratunek
# w towarzystwie gromady psów ratowniczych, z mapą lasu w ręku. Ramsay stosował dwie metody poszukiwań:
# a) Wypuszczając psy we wszystkich możliwych kierunkach na każdym skrzyżowaniu
# b) Wypuszczając psy tak daleko jak to możliwe w jednym kierunku i cofając się
#    do ostatniego skrzyżowania po napotkaniu ślepej uliczki
#
# Pomóż Ramsayowi ocalić Niewiastę : napisz algorytm, który pozwoli przeszukać cały las i znaleźć niewiastę.
# Psy Ramsaya mogą się poruszać w czterech kierunkach : góra, dół, prawo, lewo. Ruch po przekątnej jest zabroniony.
# Pamiętaj żeby nie przeszukiwać kilka razy tych samych miejsc!
# Zadanie należy rozwiązać na 2 sposoby odpowiadające metodom Ramsaya a) oraz b). Jako rezultat program powinien
# wypisać kolejno odwiedzane współrzędne na mapie.
#
# Oznaczenia na mapie lasu:
# - '#' - przeszkoda
# - ' ' - droga, po której można się poruszać
# - 'R' - pozycja startowa Ramsaya
# - 'N' - pozycja Niewiasty
#
# Wskazówka 1 : W metodzie a) przydatna może się okazać kolejka.
# Wskazówka 2 : W meotdzie b) przydatny może się okazać stos.
# Wskazówka 3 : Po mapie można pisać, np. oznaczając miejsca w których się było specjalnym symbolem.

from collections import deque

R = (7, 5)

FOREST = [list("#########"),
          list("#N      #"),
          list("####### #"),
          list("# #     #"),
          list("# # ### #"),
          list("#     # #"),
          list("#####   #"),
          list("#    R  #"),
          list("#   #  ##"),
          list("#########")]

def print_map():
    for i in range(len(FOREST)):
        print("".join(FOREST[i]))


if __name__ == '__main__':
    print_map()