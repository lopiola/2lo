# -*- coding: utf-8 -*-

# Jesteś administratorem na Katedrze Informatyki AGH i właśnie dostałeś listę nowych studentów.
# Musisz założyć im konta pocztowe, ale oczywiście jako admin nigdy nie masz czasu,
# a już na pewno nie na ręczne generowanie loginów. Dlatego będziesz potrzebował programu, który dla każdego
# imienia i nazwiska studenta wypisze proponowany adres mailowy, na który składać się będą: pierwsze 3 litery nazwiska,
# pierwsze 2 litery imienia oraz adres student.agh.edu.pl.
# Np. dla nazwiska "Budynek Piotr" program powinien wypisać "budpi@student.agh.edu.pl".
#
# Pamiętaj że:
# - dostajesz tekst w formacie "Nazwisko Imię", bez podziału na wyrazy
# - w adresach mailowych nie ma dużych liter


USERS = [
    "Antos Michał",
    "Dumnicki Dariusz",
    "Furtak Weronika",
    "Jastrzębski Michał"
    "Kosak Katarzyna",
    "Kot Tomasz",
    "Kubińska Weronika",
    "Maciąg Piotr",
    "Niedźwiecki Jakub",
    "Obszański Mateusz",
    "Pilecki Mateusz",
    "Piotrowski Michał",
    "Pluszyński Łukasz",
    "Popielarz Jakub",
    "Sawa Rafał",
    "Strzeboński Aleksander",
    "Tomala Krzysztof"
    "Tomana Urszula",
    "Twardy Filip",
    "Witek Piotr",
    "Wojtaszek Daniel",
    "Wojtulewicz Mateusz",
    "Wójtowicz Magdalena",
    "Blina Grzegorz",
]


if __name__ == '__main__':

    for user in USERS:
        login = ""
        print(login)
