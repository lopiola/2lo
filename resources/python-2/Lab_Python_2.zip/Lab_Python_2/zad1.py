# -*- coding: utf-8 -*-

if __name__ == '__main__':

    a = "Podział tekstu na wyrazy to nie takie proste zadanie. " \
        "Najpierw trzeba usunąć z tekstu znaki interpunkcyjne - przecinki, kropki i myślniki. " \
        "Spróbuj to zrobić na tym tekście. "

    print()


    b = "Dla wygody często zamienia się też wszystkie duże litery na małe. Wykonaj taką operację na tym tekście. "

    print(b)


    c = "Oczywiście trzeba jeszcze pociąć tekst w miejscach gdzie pojawia się spacja. Najpierw potnij na próbę ten tekst. "

    print(c)


    d = "Ok, masz już wszystko co trzeba. Teraz połącz teksty a-d w jeden i wykonaj na nim wszystkie powyższe operacje. " \
        "Potem napisz program, który wczyta ciąg znaków podany z klawiatury i wypisze te wyrazy, które się od niego zaczynają."


    words = []



