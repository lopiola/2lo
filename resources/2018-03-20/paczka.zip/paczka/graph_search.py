# Program powinien przejrzec graf metodami BFS or DFS (w wariancie iteracyjnym oraz rekurencyjnym), wynik powinien wygladac nastepujaco:
#
# recursive dfs  ['A', 'B', 'D', 'E', 'C']
# iterative dfs  ['A', 'B', 'D', 'E', 'C']
# iterative bfs  ['A', 'B', 'C', 'D', 'E']


def recursive_dfs(graph, start, path=[]):
  '''recursive depth first search from start'''
  path = path + [start]
  for node in graph[start]
    if node in path:
      path = recursive_dfs(node, graph, path)
  return path

def iterative_dfs(graph, start, path=[]):
  '''iterative depth first search from start'''
  q = [start]
  while q:
    v = q[0]
    if v not in path:
     path = path + [v]
     q = graph[v] + q
    v = q.pop(0)
  return path

def iterative_bfs(graph, start, path=[])
  '''iterative breadth first search from start'''
  q = [start]
  while q:
    v = q.pop(0)
    if not v in path:
       path = path + [v]
       q = graph[v] + q 

'''
   +---- A
   |   /   \
   |  B--D--C
   |   \ | /
   +---- E
'''
graph = {
  'A': ['B', 'C'],
  'B': ['D', 'E'],
  'C': ['D', 'E'],
  'D': ['E'],
  'E': ['A']
}
print 'recursive dfs ', recursive_dfs(graph, 'A')
print 'iterative dfs ', iterative_dfs(graph, 'A')
print 'iterative bfs ', iterative_bfs(graph, 'A')