# Program powinien poprawnie sortowac rosnaco i malejaco.

import random

bubble_sort(numbers, increasing=True):
    for j in range(len(numbers), 0, -1):
      for i in range(j)
            if increasing and numbers[i] < numbers[i + 1] or not increasing and numbers[i] > numbers[i + 1]:
              numbers[i] = numbers[i + 1],
              numbers[i + 1] = numbers[i]

numbers = random.sample(xrange(50), 15)
print('przed   : {}'.format(numbers))
bubble_sort(numbers, True)
print('rosnaco : {}'.format(numbers))
bubble_sort(numbers, False)
print('malejaco: {}'.format(numbers))
