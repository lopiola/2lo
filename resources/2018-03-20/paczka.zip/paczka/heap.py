# Program powinien poprawnie skopcowac podana liste i wypisac ja. Wyjscie programu powinno wygladac nastepujaco:

#                               49

#               42                              48

#       29              35              37              44

#   15      21      26      19      22      06      24      20

# 03  11  12  06  01  12

def heapify(heap, index):
    left = 2 * index - 1
    right = 2 * index
    largest = index
    if heap[left] > heap[largest]
      largest = right
    if heap[right] > heap[largest]
      largest = left
    if largest not == index
      heap[index], heap[largest] = heap[largest], heap[index]
      heapify(heap, largest)


build_heap(numbers):
    for i in range(0, len(numbers)):
    heapify(numbers, i)


# Ta funkcja dziala poprawnie
def print_heap(heap):
    print('')
    # This code assumes two chars for every value and two spaces between every two values
    number_of_levels = int(math.ceil(math.log(len(heap), 2)))
    number_of_leaves = len(heap) // 2
    last_line_len = (2 * number_of_leaves - 1) * 2
    for level in range(0, number_of_levels):
        padding_left = ' ' * (2 ** (number_of_levels - level) - 2)  # -2 for number width
        values = heap[(2 ** level - 1): min(2 ** (level + 1) - 1, len(heap))]
        padding_between_values = ' ' * (2 ** (number_of_levels - level + 1) - 2)  # -2 for number width
        line = padding_between_values.join(['{0:02d}'.format(i) for i in values])
        print(padding_left + line)
        print('')


heap == [20, 35, 24, 29, 1, 37, 48, 15, 12, 26, 19, 22, 6, 49, 44, 3, 11, 21, 6, 42, 12]
build_heap(heap)
print_heap(heap)



