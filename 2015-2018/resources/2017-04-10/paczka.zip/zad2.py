# -*- coding: utf-8 -*-
#
# Chcąc wyeliminować Supermana, Batman postanowił znaleźć strategiczne miejsce na nowe centrum dowodzenia w mieście.
# Pomóż mu znaleźć Centrum Miasta - dzielnicę o specjalnych właściwościach, rozumianą jako centrum grafu.
#
# Co to jest centrum grafu ? Jeśli zmierzymy ścieżki między danym wierzchołkiem a wszystkimi pozostałymi w grafie
# i wybierzemy najdłuższą, otrzymamy miarę "centralności" wierzchołka. Jeśli obliczymy taką miarę dla wszystkich
# wierzchołków i wybierzemy najkrótszą z nich - otrzymamy centrum grafu!
#
# Program powinien wczytać graf bvs.gml, znaleźć jego centrum i wypisać (zarówno wierzchołek, jak i długość najdłuższej ścieżki).
#
# Wskazówka : skorzystaj z algorytmów z zad1, wystarczy tylko lekko zmodyfikować jeden z nich.




if __name__ == '__main__':

