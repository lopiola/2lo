# -*- coding: utf-8 -*-

# Przerob program z zadania drugiego tak, aby uzywal sita eratostenesa.
# Przygotowanie sita dla liczb do miliona pozwoli znaleźć pierwsze 78498 liczb pierwszych.
# Czy widzisz roznice w szybkosci dzialania wzgledem zadania drugiego?
# Przykladowe poprawne odpowiedzi:
#
# | n     | liczba |
# |-------|--------|
# | 2     | 3      |
# | 78    | 397    |
# | 10001 | 104743 |

import sys
import math

if __name__ == '__main__':
    pass
