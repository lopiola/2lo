# -*- coding: utf-8 -*-

# Kwadratowe liczby pierwsze (zrodlo: https://projecteuler.net/problem=27)
#
# Euler odkryl ciekawa formule: n^2 + n + 41
#   formula ta generuje tylko liczby pierwsze dla kolejnych 'n' z przedzialu <0, 39> !
#
# Nastepnie odkryto inna niezwykla formule: n^2 - 79*n + 1601
#   produkuje ona tylko liczby pierwsze dla 'n' z przedzialu <0, 79> !
#
# Uzywajac sita Eratostenesa zaimplementowanego w zadaniu 3, rozwaz wszystkie przypadki wzoru:
#
#   n^2 + a*n + b
#
#   gdzie:
#       a E < -1000, 1000 >
#       b E < -1000, 1000 >
#
# 1) Wypisz wszystkie wartosci a oraz b, dla ktorych wzor generuje co najmniej 20 liczb pierwszych dla kolejnych
#       wartosci 'n', poczawszy od zera.
# 2) Podaj wartosci a i b, dla ktorych liczba kolejno generowanych liczb pierwszych jest najwieksza.


import sys
import math

if __name__ == '__main__':
    pass
