# -*- coding: utf-8 -*-

# Napisz program, ktory sprawdzi czy liczba zadana poprzez argument programu jest liczba pierwsza.
# Program powinien wypisac "TAK" lub "NIE".
# Przykladowe liczby pierwsze, ktorymi mozna zweryfikowac poprawnosc programu:
# 113
# 173
# 223
# 281
# 421
# 593
# 691
# 1033
# 1097
# 1231
# 1373
# 1447
# 1601

import sys
import math

if __name__ == '__main__':
    pass
