# -*- coding: utf-8 -*-

# Napisz program, ktory wypisze na ekran n-ta liczbe pierwsza. Uzyj procedury sprawdzajacej z zadania pierwszego.
# Dla jakiego zadanego 'n' program zaczyna dzialac wolno?
# Przykladowe poprawne odpowiedzi:
#
# | n     | liczba |
# |-------|--------|
# | 2     | 3      |
# | 78    | 397    |
# | 10001 | 104743 |

import sys
import math

if __name__ == '__main__':
    pass
