#!/usr/bin/env python

import sys
import time
import random


# Implementacja gry w zycie w konsoli. Dla ciekawskich: https://pl.wikipedia.org/wiki/Gra_w_%C5%BCycie
# Spojrz do glownej funkcji programu i wykonuj poszczegolne etapy.
# Do poprawnego wykonania kazdego z etapow wymagane jest zaimplementowanie odpowiednich funkcji (oznaczone jako Zadanie N)
# Plansza powinna byc przechowywana w zmiennej zawierajacej tablice dwuwymiarowa (lista list)


# Dlugosc boku planszy
#   18 to minimum aby pentadecathlon i pulsar dzialaly poprawnie
#   50 to minimum aby glider-gun dziaal poprawnie
BOARD_SIZE = 20
# Ile komorek powinno zostac wylosowanych przy losowaniu planszy
RANDOMIZATION_SIZE = int(BOARD_SIZE * BOARD_SIZE * 0.4)

# Ile rund maksymalnie ma byc obliczonych
MAX_ROUNDS = 50
# Co ile czasu nastepuje kolejna runda (w sekundach)
ROUND_INTERVAL = 0.3

# Znak oznaczajacy zywa komorke
ALIVE_CELL_CHAR = '*'
# Znak oznaczajacy martwa komorke
DEAD_CELL_CHAR = ' '

# Znak oznaczajacy zywa komorke w pliku wejsciowym
ALIVE_CELL_CHAR_FROM_FILE = '*'

# Znak oznaczajacy martwa komorke w pliku wejsciowym
DEAD_CELL_CHAR_FROM_FILE = '-'

# Przy jakiej liczbie sasiadow zywa komorka przezyje
CELL_SURVIVES = [2, 3]
# Przy jakiej liczbie sasiadow martwa komorka ozyje
CELL_COMES_ALIVE = [3]


# TODO Zadanie 1
# Tworzy PUSTA plansze (bez zywych komorek)
# Zwraca plansze
def create_board():
    # TODO plansza powinna byc kwadratem o boku BOARD_SIZE
    # TODO martwa komorka oznaczana jest False
    return [[]]


# TODO Zadanie 2
# Wypisuje plansze board na ekran
# Plansza 4x4 ze znakami '*' dla zywych i ' ' dla martwych komorek powinna wygladac tak
#   (uzyj znakow '-' '|' '#' do ramki planszy):
#
#         #----#
#         |  * |
#         |**  |
#         |    |
#         |  * |
#         #----#
#
def print_board(board):
    # TODO uzyc znakow ALIVE_CELL_CHAR i DEAD_CELL_CHAR do zaznaczenia martwych/zywych komorek
    # TODO przydatna funkcja to
    #       sys.stdout.write(string)
    # ktora wypisuje zadany ciag bez znaku konca linii.
    # Nalezy pamietac, aby wywolac sys.stdout.flush(), zeby znaki zostaly wypisane na konsole
    # (wypisze wszystko co zostalo zgromadzone od ostatniego flush)
    print('plansza')


# TODO Zadanie 3
# Losuje stan poczatkowy planszy
# Wartosc zwracana nie jest istotna, plansza board powinna byc zmodyfikowana przez te funkcje
def randomize_board(board):
    # TODO nalezy wylosowac zywe komorki i zanaczyc je w board
    # TODO losowanie jednej komorki nalezy powtorzyc RANDOMIZATION_SIZE razy
    return False


# TODO Zadanie 4
# Liczy sasiadow komorki o wspolrzednych (x, y) na planszy board
# Zwraca wyliczona liczbe sasiadow
def count_neighbours(board, x, y):
    # TODO uwaga na warunki brzegowe!
    return 2


# TODO Zadanie 5
# Wylicza jedna runde Gry w Zycie
# Zwraca NOWA plansze board na podstawie starej, podanej przez argument
def live(board):
    # TODO czy mozemy aktualizowac te sama plansze w ktorej liczymy sasiadow?
    # TODO uzyc CELL_SURVIVES dla zywych komorek zeby stwierdzic czy przezyly
    # TODO uzyc CELL_COMES_ALIVE dla martwych komorek zeby stwierdzic czy ozyly
    return [[]]


# TODO Zadanie 6
# Wczytuje stan poczatkowy z pliku do danej planszy
# 1) jesli plansza w pliku jest mniejsza od board, wczytuje od lewego gornego naroznika
# 2) jesli plansza w pliku jest wieksza od board, wczytuje tylko to co sie miesci
# Wartosc zwracana nie jest istotna, plansza board powinna byc zmodyfikowana przez te funkcje
def import_board_from_file(board, file_path):
    # TODO nalezy uzyc ALIVE_CELL_CHAR_FROM_FILE i/lub DEAD_CELL_CHAR_FROM_FILE
    return False


# Glowna funkcja programu
if __name__ == '__main__':
    # TODO etap 1) Stworz pusta plansze i wypisz ja na ekran (zad 1+2)
    board = create_board()
    print_board(board)

    # TODO etap 2) Stworz plansze, wylosuj jej stan poczatkowy, wypisz na ekran (zad 3)

    # TODO etap 3) Stworz plansze, wylosuj jej stan poczatkowy, nastepnie w petli: (zad 4+5)
    #                           wypisz kilka pustych linii, aby bylo czytelniej
    #                           wypisz numer rundy (np. 'RUNDA: 13')
    #                           wypisz plansze
    #                           wylicz kolejna runde i zaktualizuj plansze
    #                           poczekaj chwile ( time.sleep(ilosc_sekund) )
    #                           powtorz
    # TODO          uzyj MAX_ROUNDS aby ograniczyc ilosc rund symulacji
    # TODO          uzyj SLEEP_INTERVAL aby okreslic ile czasu czekac miedzy rundami

    # TODO etap 4) Dopisz obsluge przerwania Ctrl+C, ktore wypisze 'Koniec!' i zakonczy program

    # TODO etap 5) Dopisz mozliwosc importu z pliku (zad 6)
    # TODO           jesli podamy nazwe pliku jako argument, wczytujemy z pliku
    # TODO           jesli nic nie podamy, losujemy plansze



