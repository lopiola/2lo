# -*- coding: utf-8 -*-
# Dysponując przetworzonymi danymi billingowymi możesz już zająć się analizą kryminalną.
# Napisz program, który wczyta słownik z pliku family-calls.sav i poda dla wybranego przez użytkownika numeru telefonu:
# - imię i nazwisko danej osoby
# - zestawienie połączeń danej osoby z innymi w formacie: { imię i nazwisko odbierającej osoby : liczba połączeń }

import pickle

if __name__ == '__main__':


