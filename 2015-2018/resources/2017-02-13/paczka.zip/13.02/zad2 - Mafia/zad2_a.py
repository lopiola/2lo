# -*- coding: utf-8 -*-
# Chcąc rozpracować przestępczą siatkę, zdobyłeś dane billingowe podejrzanej grupy osób.
# Zanim je przeanalizujesz, musisz jednak je przetworzyć do wygodnego dla Ciebie formatu.
# Dane są zapisane w pliku .csv, a ich interpretacja jest następująca:
# - każdy wiersz oznacza pojedynczą rozmowę między dwoma osobami
# - wiersz składa się z trzech wartości rozdzielonych przecinkiem:
#   imię i nazwisko osoby dzwoniącej, numer osoby dzwoniącej, numer osoby odbierającej
# Przykładowy wpis wygląda następująco:
# Michael Corleone,826796521,694005750
#
# Wczytaj plik family-calls.csv i stwórz na jego podstwie strukturę danych w postaci:
#
# { numer_osoby : (imię_i_nazwisko_osoby, [nr_odbierający1, nr_odbierający2, ...]) }
#
# Wyjaśnienie: struktura reprezentuje słownik, w którym kluczami są numery telefonów, a wartościami krotki
# zawierające imię i nazwisko osoby, do której należy numer z klucza oraz listę numerów reprezentujących wychodzące
# połączenia telefoniczne danej osoby
#
# Otrzymaną strukturę wypisz i zapisz w pliku familly-calls.sav. Użyj modułu pickle.

import pickle



if __name__ == '__main__':




