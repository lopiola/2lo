# -*- coding: utf-8 -*-
# Stworzone archiwum jest kompaktowe, ale wymaga wygodnego mechanizmu korzystania z niego
# by móc z łatwością śledzić plugawe sługi chaosu. Musisz przygotować jeszcze procedurę
# pozyskiwania z niego informacji.
#
# Przygotuj odwrotny program. Powinien otwierać plik gz i zapisywać rozpakowaną zawartość.

import gzip


if __name__ == '__main__':
    pass