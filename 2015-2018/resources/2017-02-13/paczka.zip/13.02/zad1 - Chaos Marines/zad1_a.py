# -*- coding: utf-8 -*-
# Do Inkwizycji wpłynął raport z sektora Calixis, zawierający wysokiej jakości zdjęcie przedstawiające
# wrogie operacje w regionie. Jednakże obrazy tego rozmiaru są zbyt duże nawet dla przepastnych archiwów
# Ordo Hereticus. Twoim obowiązkiem jako młodego skryby jest przygotowanie procedury, która skompresuje
# otrzymaną fotografię przed jej skatalogowaniem.
#
# Użyj modułu gzip. Skompresuj załączony plik do nowego z rozszerzeniem gz. Sprawdź o ile mniejszył się
# jego rozmiar. Spróbuj go rozpakować zewnętrznym programem i zweryfikuj, że zawartość jest poprawna.

import gzip


if __name__ == '__main__':
    pass